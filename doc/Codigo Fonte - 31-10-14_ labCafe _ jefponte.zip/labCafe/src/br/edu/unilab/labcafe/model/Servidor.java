package br.edu.unilab.labcafe.model;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import br.edu.unilab.labcafe.control.ControleServidor;
import br.edu.unilab.labcafe.dao.UsuarioDAO;
import br.edu.unilab.labcafe.view.TelaServidor;

/**
 * Essa classe inicia um servidor DataGram e fica dispon�vel para certos
 * clientes previamente cadastrados.
 * 
 * @author jefponte
 *
 */
public class Servidor {

	private DatagramSocket socket;
	private Thread recepcaoDePacotes;
	private ControleServidor controle;
	public void setControle(ControleServidor controle){
		this.controle = controle;
	}
	private ArrayList<Cliente> listaDeClientes;

	public Servidor() {
		this.listaDeClientes = new ArrayList<Cliente>();

		// this.servidor = new Server(this);
		try {
			this.socket = new DatagramSocket(5000);
		} catch (SocketException socketEsception) {
			socketEsception.printStackTrace();
			System.exit(1);

		}
	}

	/**
	 * Esse preenche a lista de clientes com clientes v�lidos que poder�o fazer
	 * solicita��es.
	 * 
	 */
	public void armazenaListaDeClientes() {

	}

	public void iniciaServidor() {
		controle.getTelaServidor().printNoDisplay("\nServidor Iniciado e aguardando solicita��es...");
		this.recepcaoDePacotes = new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {

					byte[] data = new byte[100];

					DatagramPacket recivePacket = new DatagramPacket(data,
							data.length);
					
					try {
						socket.receive(recivePacket);
						//String mensagemRecebida = new String(recivePacket.getData(), 0, recivePacket.getLength());
						//controle.getTelaServidor().printNoDisplay("Mensagem recebida: "+mensagemRecebida);
						InetAddress ip = recivePacket.getAddress();
						processaEntrada(recivePacket, ip);
					} catch (IOException e) {
						e.printStackTrace();
					}

				}
			}
		});
		this.recepcaoDePacotes.start();

	}
	/**
	 * Tentativa de login de algum cliente.
	 * @param entrada
	 */
	public void processaEntrada(final DatagramPacket recivePacket, InetAddress ip){
		String entrada = new String(recivePacket.getData(), 0, recivePacket.getLength());
		if(entrada.contains("login") && entrada.contains("senha") && entrada.contains(";")){
			controle.getTelaServidor().printNoDisplay("\nTentativa de Login Realizada por host: "+ip+". Na porta: "+recivePacket.getPort());
			String quebra1[] = entrada.split(";");
			String quebra2[] = quebra1[0].split("login:");
			String login = quebra2[1];
			String quebra3[] = quebra1[1].split("senha:");
			String senha = quebra3[1];
			Usuario usuario = new Usuario();
			usuario.setLogin(login);
			usuario.setSenha(senha);
			//String quebraIP[] = ip.split("/");
			

			if(login.equals("jefponte") || senha.equals("123456")){
				controle.getTelaServidor().printNoDisplay("\nO jefferson Logou!");
				String mensagem = "desbloqueia";
				byte[] data = mensagem.getBytes();
				DatagramPacket sendPacket;
				try {
					//System.out.println(ip);
					sendPacket = new DatagramPacket(data,  data.length, recivePacket.getAddress(), recivePacket.getPort());
					socket.send(sendPacket);
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Thread time = new Thread(new Runnable() {
					
					@Override
					public void run() {
						while(true){
							try {
								Thread.sleep(30000);
								controle.getTelaServidor().printNoDisplay("Darei 30 segundos para este individuo.");
								String mensagem2 = "close";
								byte[] data2 = mensagem2.getBytes();
								DatagramPacket sendPacket2;
								try {
									//System.out.println(ip);
									sendPacket2 = new DatagramPacket(data2,  data2.length, recivePacket.getAddress(), recivePacket.getPort());
									socket.send(sendPacket2);
								} catch (UnknownHostException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								break;
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
					}
				});
				time.start();
			}
			else{
				controle.getTelaServidor().printNoDisplay("\nTentativa de Login Falhou!");
				String mensagem = "errou";
				byte[] data = mensagem.getBytes();
				DatagramPacket sendPacket;
				try {
					//System.out.println(ip);
					sendPacket = new DatagramPacket(data,  data.length, recivePacket.getAddress(), recivePacket.getPort());
					socket.send(sendPacket);
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		
		
	}
	public void liberaCliente(String ip){
		String mensagem = "desbloqueia";
		byte[] data = mensagem.getBytes();
		DatagramPacket sendPacket;
		try {
			//System.out.println(ip);
			sendPacket = new DatagramPacket(data,  data.length, InetAddress.getByName(ip), 5000);
			socket.send(sendPacket);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
