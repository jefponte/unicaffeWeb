package br.edu.unilab.labcafe.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class TelaCliente extends JFrame{
	private JLabel labelLogin;
	private JLabel labelSenha;
	private JTextField campoLogin;
	private JPasswordField campoSenha;
	private JPanel painelTitulo; 
	private JPanel painelCentral;
	private JButton botaoLogar;
	
	
	private JLabel labelTitulo;
	
	
	public TelaCliente(){
		
		//inicializando tudo;
		this.labelLogin = new JLabel("Login: ");
		this.labelSenha = new JLabel("Senha: ");
		this.labelTitulo = new JLabel("LabCafe - O sistema de Controle de Laborat�rios da Unilab");
		this.campoLogin = new JTextField(15);
		this.campoSenha = new JPasswordField(15);
		this.botaoLogar = new JButton("Logar");
		this.painelTitulo = new JPanel();
		this.painelCentral = new JPanel();
		this.painelCentral.setBackground(Color.pink);
		
		//adiciona componentes
		this.setLayout(new BorderLayout());
		this.add(this.painelTitulo, BorderLayout.NORTH);
		this.painelTitulo.add(this.labelTitulo);
		this.labelTitulo.setFont(new Font("Dialog", Font.PLAIN, 26));  
		this.add(this.painelCentral, BorderLayout.CENTER);
		this.painelCentral.add(this.labelLogin, BorderLayout.CENTER);
		this.painelCentral.add(this.campoLogin);
		this.painelCentral.add(this.labelSenha);
		this.painelCentral.add(this.campoSenha);
		this.painelCentral.add(this.botaoLogar);
		
		
		
		//coisas da janela.
		this.setUndecorated(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}


	public JLabel getLabelLogin() {
		return labelLogin;
	}


	public JLabel getLabelSenha() {
		return labelSenha;
	}


	public JTextField getCampoLogin() {
		return campoLogin;
	}


	public JPasswordField getCampoSenha() {
		return campoSenha;
	}


	public JPanel getPainelTitulo() {
		return painelTitulo;
	}


	public JPanel getPainelCentral() {
		return painelCentral;
	}


	public JLabel getLabelTitulo() {
		return labelTitulo;
	}


	public JButton getBotaoLogar() {
		return botaoLogar;
	}

}
