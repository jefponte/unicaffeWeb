package br.edu.unilab.labcafe.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class TelaServidor extends JFrame {
	private JTextArea display;
	private JPanel painelTitulo;
	private JPanel painelCentral;
	private JLabel labelTitulo;
	

	public TelaServidor() {


		this.labelTitulo = new JLabel("LabCafe - O sistema de Controle de Laborat�rios da Unilab");
		this.painelTitulo = new JPanel();
		this.painelCentral = new JPanel();
		this.display = new JTextArea("Teste");
		this.display.setBackground(Color.BLACK);
		this.display.setForeground(Color.green);
		this.display.setEditable(false);
		
		
		
		this.labelTitulo.setFont(new Font("Dialog", Font.PLAIN, 26));  
		this.setLayout(new BorderLayout());
		this.painelTitulo.add(labelTitulo);
		this.add(this.painelTitulo, BorderLayout.NORTH);
		this.add(this.painelCentral, BorderLayout.CENTER);
		this.painelCentral.setLayout(new BorderLayout());
		this.painelCentral.add(new JScrollPane(this.display), BorderLayout.CENTER);
		
		// coisas da janela.
		
		this.setUndecorated(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}
	
	public void printNoDisplay(final String mensagem) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				display.append(mensagem);

			}
		});
	}

}
