package br.edu.unilab.labcafe.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import br.edu.unilab.labcafe.view.TelaCliente;
import br.edu.unilab.labcafe.view.TelaPrincipal;

public class ControlePrincipal {
	private TelaPrincipal telaPrincipal;
	public EventoPrincipal chamaServidor;
	public EventoPrincipal chamaCliente;
	
	public ControlePrincipal(){
		this.telaPrincipal = new TelaPrincipal();
		this.telaPrincipal.setVisible(true);
		this.chamaServidor = new EventoPrincipal(EventoPrincipal.EVENTO_SERVIDOR);
		this.chamaCliente = new EventoPrincipal(EventoPrincipal.EVENTO_CLIENTE);
		this.telaPrincipal.getBotaoIniciarCliente().addActionListener(this.chamaCliente);
		this.telaPrincipal.getBotaoIniciarServidor().addActionListener(this.chamaServidor);
	}
	public void iniciar(){
		
	}
	public class EventoPrincipal implements ActionListener{
		public static final int EVENTO_SERVIDOR = 0;
		public static final int EVENTO_CLIENTE = 1;
		public int evento = 1;
		public EventoPrincipal(int evento) {
			this.evento = evento;
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
			switch(this.evento){
			case EVENTO_SERVIDOR:
				ControleServidor controleServidor = new ControleServidor();
				controleServidor.iniciar();
				break;
			case EVENTO_CLIENTE:
				ControleCliente controleDeCliente = new ControleCliente();
				controleDeCliente.setTelaPrincipal(telaPrincipal);
				controleDeCliente.iniciar();
				break;
			default:
				break;
				
			}
		}
		
	}

}
