package br.edu.unilab.labcafe.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import br.edu.unilab.labcafe.model.Cliente;
import br.edu.unilab.labcafe.view.TelaCliente;
import br.edu.unilab.labcafe.view.TelaPrincipal;

public class ControleCliente {
	private Cliente cliente;
	private TelaPrincipal telaPrincipal;
	public void setTelaPrincipal(TelaPrincipal telaPrincipal){
		this.telaPrincipal = telaPrincipal;
	}
	private TelaCliente telaDeCliente;
	private EventoCliente eventoTentarLogar;
	public ControleCliente(){
		this.eventoTentarLogar = new EventoCliente(EventoCliente.EVENTO_TENTA_LOGAR);
		this.telaDeCliente = new TelaCliente();
		this.telaDeCliente.setVisible(true);
		this.cliente = new Cliente();
		
		this.telaDeCliente.getBotaoLogar().addActionListener(this.eventoTentarLogar);
		this.cliente.setControle(this);
		
	}
	public TelaCliente getTelaDoCliente(){
		return this.telaDeCliente;
	}
	public void iniciar(){
		this.cliente.iniciaCliente();
		
	}
	public void bloqueiaTela(){
		this.telaDeCliente.setExtendedState(JFrame.MAXIMIZED_BOTH);
		//JOptionPane.showMessageDialog(null, "Seu tempo foi de 30 segundos e esgotou!");
	}
	public void desbloqueiaTela(){
		this.telaDeCliente.setExtendedState(JFrame.NORMAL);
		this.telaPrincipal.setExtendedState(JFrame.NORMAL);
		
		
		
	}
	public void errouASenha(){
		JOptionPane.showMessageDialog(null, "Errou a senha!");
	}
	public class EventoCliente implements ActionListener{
		
		public static final int EVENTO_TENTA_LOGAR = 0;
		public static final int EVENTO_LIBERA_JANELA = 1;
		public static final int EVENTO_BLOQUEIA_JANELA = 2;
		
		
		
		public int evento = 1;
		
		public EventoCliente(int evento) {
			// TODO Auto-generated constructor stub
			this.evento = evento;
		}
		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
		
			switch(this.evento){
			case EVENTO_TENTA_LOGAR:
				cliente.enviaMensagem("login:"+telaDeCliente.getCampoLogin().getText().toString()+";senha:"+telaDeCliente.getCampoSenha().getText().toString());
				telaDeCliente.getCampoLogin().setText("");
				telaDeCliente.getCampoSenha().setText("");
				//desbloqueiaTela();
				break;
			
			default:
				break;
				
			}
		}
		
	}

}
