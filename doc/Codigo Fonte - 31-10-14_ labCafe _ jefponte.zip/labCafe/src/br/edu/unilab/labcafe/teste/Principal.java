package br.edu.unilab.labcafe.teste;

import br.edu.unilab.labcafe.control.ControlePrincipal;
import br.edu.unilab.labcafe.view.TelaCliente;
import br.edu.unilab.labcafe.view.TelaPrincipal;
import br.edu.unilab.labcafe.view.TelaServidor;

public class Principal {

	
	
	public static void main(String[] args) {
		ControlePrincipal controlePrincipal = new ControlePrincipal();
		controlePrincipal.iniciar();
		
	}
}
