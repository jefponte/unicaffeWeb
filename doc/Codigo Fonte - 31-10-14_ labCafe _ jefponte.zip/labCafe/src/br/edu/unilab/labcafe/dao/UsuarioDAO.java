package br.edu.unilab.labcafe.dao;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import br.edu.unilab.labcafe.model.Usuario;


public class UsuarioDAO extends DAO{
	
	
	/**
	 * Este método faz a insersão de usuários no banco de dados. 
	 * @param usuario
	 * @return
	 */
	
	public boolean inserir(Usuario usuario){
		Statement stmt = null;
		
		try {
			this.getConexao().setAutoCommit(false);
			stmt = this.getConexao().createStatement();
			String sql = "INSERT into usuario (nome, email, senha, login) values('"+usuario.getNome()+"', '"+usuario.getEmail()+"', '"+usuario.getLogin()+"', '"+usuario.getSenha()+"');";
			stmt.executeUpdate(sql);
			stmt.close();
			this.getConexao().commit();
			this.getConexao().close();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
		
	}
	public ArrayList<Usuario> retornaLista(){
		Statement stmt = null;
		ArrayList<Usuario> lista = new ArrayList<Usuario>();
		try {
			this.getConexao().setAutoCommit(false);
			stmt = this.getConexao().createStatement();
			String sql = "SELECT * FROM usuario;";
			
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				
				
				Usuario u = new Usuario();
				u.setId(rs.getInt("id"));
				u.setNome(rs.getString("nome"));
				u.setEmail(rs.getString("email"));
				u.setLogin(rs.getString("login"));
				u.setSenha(rs.getString("senha"));
				lista.add(u);
				
			}
			stmt.close();
			this.getConexao().commit();
			this.getConexao().close();
			return lista;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	

}
