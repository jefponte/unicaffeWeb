package br.edu.unilab.labcafe.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import br.edu.unilab.labcafe.model.Servidor;
import br.edu.unilab.labcafe.view.TelaServidor;

public class ControleServidor {
	
	private TelaServidor telaDeServidor;
	private Servidor servidor;
	
	public ControleServidor(){
		this.telaDeServidor = new TelaServidor();
		this.telaDeServidor.setVisible(true);
	}
	public TelaServidor getTelaServidor(){
		return this.telaDeServidor;
	}
	public void iniciar(){
		this.telaDeServidor.printNoDisplay("\nServidor Iniciando");
		this.servidor = new Servidor();
		this.servidor.setControle(this);
		this.telaDeServidor.printNoDisplay("\nArmazenando Clientes..");
		this.servidor.armazenaListaDeClientes();
		this.servidor.iniciaServidor();
	}
	public class EventoServidor implements ActionListener{
		
		public static final int EVENTO_SERVIDOR = 0;
		public static final int EVENTO_CLIENTE = 1;
		public int evento = 1;
		
		public EventoServidor(int evento) {
			this.evento = evento;
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
		
			switch(this.evento){
			case EVENTO_SERVIDOR:
				ControleServidor controleServidor = new ControleServidor();
				controleServidor.iniciar();
				break;
			case EVENTO_CLIENTE:
				ControleCliente controleDeCliente = new ControleCliente();
				controleDeCliente.iniciar();
				break;
			default:
				break;
				
			}
		}
		
	}

}
