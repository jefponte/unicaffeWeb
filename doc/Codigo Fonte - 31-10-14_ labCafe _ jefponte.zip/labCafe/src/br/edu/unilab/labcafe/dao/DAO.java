package br.edu.unilab.labcafe.dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Esta classe guarda a conexão 
 * Ela deverá ser usada para acionar uma conexão com 
 * banco de dados sem se preocupar muito com parâmetros. 
 * @author unilab
 *
 */
public class DAO {
	
	private Connection conexao;
	
	public DAO(){
		conexao = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      conexao = DriverManager.getConnection("jdbc:sqlite:banco.db");
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
		
	}

	public Connection getConexao() {
		return conexao;
	}

	public void setConexao(Connection conexao) {
		this.conexao = conexao;
	}
	

}
