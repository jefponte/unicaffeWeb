package br.edu.unilab.labcafe.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TelaPrincipal extends JFrame{
	private JButton botaoIniciarServidor;
	private JButton botaoIniciarCliente;
	
	private JLabel labelTitulo;
	private JPanel painelPrincipal;
	private JPanel painelDeBotoes;

	
	public TelaPrincipal(){
		this.labelTitulo = new JLabel("LabCafe - O sistema de Controle de Laborat�rios da Unilab");
		this.labelTitulo.setFont(new Font("Dialog", Font.PLAIN, 26));  
		this.setLayout(new BorderLayout());
		this.setTitle("LabCaf� - O sistema de Controle de laborat�rios da UNILAB");
		this.botaoIniciarServidor = new JButton("Iniciar Servidor");
		this.botaoIniciarCliente = new JButton("Iniciar Cliente");
		this.painelPrincipal = new JPanel();

		this.add(this.painelPrincipal, BorderLayout.NORTH);
		this.setUndecorated(true);
		
		this.painelPrincipal.add(this.labelTitulo, BorderLayout.NORTH);
		
		this.painelDeBotoes = new JPanel();
		
		this.painelDeBotoes.setBackground(Color.LIGHT_GRAY);
		this.painelDeBotoes.add(this.botaoIniciarServidor);
		this.painelDeBotoes.add(this.botaoIniciarCliente);
		this.add(this.painelDeBotoes, BorderLayout.CENTER);
		//this.painelDeBotoes.setLayout(new BorderLayout());
		this.painelDeBotoes.add(this.botaoIniciarServidor);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}


	public JButton getBotaoIniciarServidor() {
		return botaoIniciarServidor;
	}



	public JButton getBotaoIniciarCliente() {
		return botaoIniciarCliente;
	}




	public JLabel getLabelTitulo() {
		return labelTitulo;
	}




	public JPanel getPainelPrincipal() {
		return painelPrincipal;
	}




	public JPanel getPainelDeBotoes() {
		return painelDeBotoes;
	}




}
