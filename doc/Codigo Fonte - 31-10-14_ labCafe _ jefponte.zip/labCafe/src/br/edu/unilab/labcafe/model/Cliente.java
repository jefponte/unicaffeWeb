package br.edu.unilab.labcafe.model;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import br.edu.unilab.labcafe.control.ControleCliente;

public class Cliente {
	
	private DatagramSocket socket;
	private ControleCliente controle;
	private Thread recepcaoDePacotes;
	public void setControle(ControleCliente controle){
		this.controle = controle;
	}
	public Cliente(){
			try {
				socket = new DatagramSocket();
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//byte[] data = mensagemInicial.getBytes();
			//DatagramPacket sendPacket = new DatagramPacket(data,  data.length, InetAddress.getLocalHost(), 5000);
			//socket.send(sendPacket);
			//labelLogin.setText("Tentando Logar. Calma a�");
			
	}
	
	public void iniciaCliente(){
		
		this.recepcaoDePacotes = new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {

					byte[] data = new byte[100];
				
					DatagramPacket recivePacket = new DatagramPacket(data,
							data.length);
					
					try {
						socket.receive(recivePacket);
						String mensagemRecebida = new String(recivePacket.getData(), 0, recivePacket.getLength());
						//controle.getTelaServidor().printNoDisplay("Mensagem recebida: "+mensagemRecebida);
						String ip = recivePacket.getAddress().toString();
						//System.out.println(mensagemRecebida);
						processaMensagem(mensagemRecebida, ip);
					} catch (IOException e) {
						e.printStackTrace();
					}

				}
			}
		});
		this.recepcaoDePacotes.start();
		
		/*
		while(true){
			try{
				byte[] data = new byte[100];
				DatagramPacket receivePacket = new DatagramPacket(data,  data.length);
				socket.receive(receivePacket);
				String mensagemRecebida = receivePacket.getAddress().toString();
				processaMensagem(mensagemRecebida);
				
			}catch(IOException exception){
				exception.printStackTrace();
			}
			
			
		}
		peda�o com erro
		*/
	}
	public void processaMensagem(String mensagem, String ip){
		
		if(mensagem.contains("close")){
			System.out.println("Cliente bloqueado");
			this.controle.bloqueiaTela();
			
		}
		else if (mensagem.contains("desbloqueia")) {
			System.out.println("Cliente desbloqueado");
			this.controle.desbloqueiaTela();
		}else if (mensagem.contains("errou")) {
			this.controle.errouASenha();
			
		}
		
	}
	public boolean enviaMensagem(String mensagem) {
		byte[] dados = mensagem.getBytes();
		DatagramPacket mensagemEnviada;
		try {
			
			mensagemEnviada = new DatagramPacket(dados, dados.length, InetAddress.getByName("10.5.3.146"), 5000);
			this.socket.send(mensagemEnviada);
			return true;
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}
	


}
